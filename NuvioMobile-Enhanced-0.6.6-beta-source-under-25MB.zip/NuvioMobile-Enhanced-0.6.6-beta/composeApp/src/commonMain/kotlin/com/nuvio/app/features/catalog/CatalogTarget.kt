package com.nuvio.app.features.catalog

import com.nuvio.app.features.details.MoreLikeThisSource
import com.nuvio.app.features.library.LibrarySortOption
import kotlinx.serialization.Serializable

sealed interface CatalogTarget {
    val contentType: String
    val supportsPagination: Boolean

    data class Addon(
        val manifestUrl: String,
        override val contentType: String,
        val catalogId: String,
        val genre: String? = null,
        override val supportsPagination: Boolean = false,
    ) : CatalogTarget

    data class Library(
        override val contentType: String,
        val sectionType: String,
        val sortOption: LibrarySortOption = LibrarySortOption.DEFAULT,
    ) : CatalogTarget {
        override val supportsPagination: Boolean = false
    }

    data class MoreLikeThis(
        val itemId: String,
        val itemType: String,
        val source: MoreLikeThisSource,
    ) : CatalogTarget {
        override val contentType: String get() = itemType
        override val supportsPagination: Boolean = true
    }

    data class Server(
        val connectionId: String,
        val libraryId: String?,
        override val contentType: String,
        val collectionId: String? = null,
    ) : CatalogTarget {
        override val supportsPagination: Boolean = true
    }

    data class CollectionSource(
        val collectionId: String,
        val folderId: String,
        val sourceKey: String,
        override val contentType: String,
        override val supportsPagination: Boolean = false,
    ) : CatalogTarget
}

@Serializable
enum class CatalogTargetKind {
    ADDON,
    LIBRARY,
    COLLECTION_SOURCE,
}
