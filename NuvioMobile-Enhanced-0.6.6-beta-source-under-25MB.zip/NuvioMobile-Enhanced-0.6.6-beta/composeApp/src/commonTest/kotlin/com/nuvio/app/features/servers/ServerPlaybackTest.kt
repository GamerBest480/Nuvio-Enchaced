package com.nuvio.app.features.servers

import com.nuvio.app.features.streams.AddonStreamGroup
import com.nuvio.app.features.streams.StreamAutoPlayMode
import com.nuvio.app.features.streams.StreamAutoPlaySelector
import com.nuvio.app.features.streams.StreamAutoPlaySource
import com.nuvio.app.features.streams.isSelectableForPlayback
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlin.test.AfterTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertNull
import kotlin.test.assertTrue

class ServerPlaybackTest {
    @AfterTest
    fun tearDown() = removeFakeServer()

    @Test
    fun nativeRequestsProduceOneAttributedGroup() = runTest {
        val connection = installFakeServer()
        val videoId = ServerItemRef(connection.id, "42").encode()

        val sources = ServerStreams.sources(type = "movie", videoId = videoId, season = null, episode = null)
        val group = sources.single().load()

        assertEquals("Fake · Box", group.addonName)
        assertTrue(ServerStreams.isServerSourceId(group.addonId))
        val stream = group.streams.single()
        assertEquals(ServerPlaybackTarget(ServerItemRef(connection.id, "42"), "src-42"), stream.serverTarget)
        assertNull(stream.playableDirectUrl)
        assertTrue(stream.hasPlayableSource)
        assertTrue(stream.needsServerPreparation)
        assertFalse(stream.isTorrentStream)
        assertTrue(stream.isSelectableForPlayback(debridEnabled = false))
    }

    @Test
    fun serverItemsAndMatchableCatalogTitlesArePlayable() {
        val connection = installFakeServer()
        assertTrue(ServerStreams.canServe("movie", ServerItemRef(connection.id, "42").encode()))
        assertTrue(ServerStreams.canServe("movie", "tt0111161"))
        assertTrue(ServerStreams.canServe("series", "tt0944947:1:1"))
        assertFalse(ServerStreams.canServe("movie", "someaddon:1"))
        assertFalse(ServerStreams.canServe("movie", ServerItemRef("cmissing", "42").encode()))

        ServerRepository.setEnabled(connection.id, false)
        assertFalse(ServerStreams.canServe("movie", ServerItemRef(connection.id, "42").encode()))
        assertFalse(ServerStreams.canServe("movie", "tt0111161"))
    }

    @Test
    fun catalogDetailsSettingListsServerFilesFirst() = runTest {
        val connection = installFakeServer()
        assertFalse(ServerStreams.sources("movie", "tt0111161", null, null).single().preferred)

        ServerRepository.setCatalogMetadata(connection.id, true)
        val source = ServerStreams.sources("movie", "tt0111161", null, null).single()
        assertTrue(source.preferred)

        val addon = AddonStreamGroup(addonName = "Addon", addonId = "addon:a", streams = emptyList())
        val ordered = StreamAutoPlaySelector.orderAddonStreams(
            groups = listOf(addon, source.loadingGroup()),
            installedOrder = listOf("Addon"),
            preferredGroupIds = setOf(source.addonId),
        )
        assertEquals(listOf(source.addonId, "addon:a"), ordered.map { it.addonId })
    }

    @Test
    fun autoplayCanChooseServerCandidates() = runTest {
        val connection = installFakeServer()
        val stream = ServerStreams.candidates(ServerItemRef(connection.id, "42")).single()

        val selected = StreamAutoPlaySelector.selectAutoPlayStream(
            streams = listOf(stream),
            mode = StreamAutoPlayMode.FIRST_STREAM,
            regexPattern = "",
            source = StreamAutoPlaySource.INSTALLED_ADDONS_ONLY,
            installedAddonNames = emptySet(),
            selectedAddons = emptySet(),
            selectedPlugins = setOf("Some plugin"),
        )
        assertEquals(stream, selected)
    }

    @Test
    fun reportsLifecycleInOrderAndStopsOnce() = runTest {
        val provider = FakeServerProvider()
        val connection = installFakeServer(provider)
        val stream = ServerStreams.candidates(ServerItemRef(connection.id, "42")).single()

        val prepared = ServerPlayback.prepare(stream)
        val url = assertNotNull(prepared.playableDirectUrl)
        assertTrue(ServerPlayback.isServerSource(url))

        ServerPlayback.onPlaybackSnapshot(url, 0L, isPlaying = false, isLoading = true, isEnded = false)
        ServerPlayback.onPlaybackSnapshot(url, 0L, isPlaying = true, isLoading = false, isEnded = false)
        ServerPlayback.onPlaybackSnapshot(url, 1_000L, isPlaying = false, isLoading = false, isEnded = false)
        ServerPlayback.onPlaybackSnapshot(url, 1_000L, isPlaying = true, isLoading = false, isEnded = false)
        ServerPlayback.onPlaybackSnapshot(url, 2_000L, isPlaying = false, isLoading = false, isEnded = true)
        ServerPlayback.stop(url)

        val expected = listOf(
            ServerPlaybackEventType.START,
            ServerPlaybackEventType.PAUSE,
            ServerPlaybackEventType.RESUME,
            ServerPlaybackEventType.STOP,
        )
        withContext(Dispatchers.Default) {
            withTimeout(5_000L) { while (provider.reported.size < expected.size) delay(10) }
        }
        assertEquals(expected, provider.reported.toList())
        assertFalse(ServerPlayback.isServerSource(url))
    }

    @Test
    fun providerWithoutTranscodingHasNoFallback() = runTest {
        val connection = installFakeServer()
        val prepared = ServerPlayback.prepare(ServerStreams.candidates(ServerItemRef(connection.id, "7")).single())
        val url = assertNotNull(prepared.playableDirectUrl)

        assertNull(ServerPlayback.fallback(url))
        ServerPlayback.stop(url)
    }

    @Test
    fun switchesTranscodeAudioByRestartingTheSession() = runTest {
        val provider = FakeServerProvider(transcodes = true)
        val connection = installFakeServer(provider)
        val prepared = ServerPlayback.prepare(ServerStreams.candidates(ServerItemRef(connection.id, "42")).single())
        val url = assertNotNull(prepared.playableDirectUrl)
        assertEquals(listOf(1 to true, 2 to false), ServerPlayback.audioTracks(url).map { it.index to it.selected })

        val switched = assertNotNull(ServerPlayback.switchAudio(url, 2))

        val request = provider.playbackRequests.last()
        assertEquals(2, request.audioStreamIndex)
        assertFalse(request.capabilities.allowDirectPlay)
        assertFalse(ServerPlayback.isServerSource(url))
        assertTrue(ServerPlayback.isServerSource(switched.url))
        assertEquals(listOf(1 to false, 2 to true), ServerPlayback.audioTracks(switched.url).map { it.index to it.selected })
        withContext(Dispatchers.Default) {
            withTimeout(5_000L) { while (ServerPlaybackEventType.STOP !in provider.reported) delay(10) }
        }
        ServerPlayback.stop(switched.url)
    }

    @Test
    fun burnsInSubtitlesByRestartingTheTranscode() = runTest {
        val provider = FakeServerProvider(transcodes = true)
        val connection = installFakeServer(provider)
        val url = assertNotNull(ServerPlayback.prepare(ServerStreams.candidates(ServerItemRef(connection.id, "42")).single()).playableDirectUrl)
        val japanese = assertNotNull(ServerPlayback.switchAudio(url, 2))

        val burnedIn = assertNotNull(ServerPlayback.switchSubtitle(japanese.url, 3))

        val request = provider.playbackRequests.last()
        assertEquals(3, request.subtitleStreamIndex)
        assertEquals(2, request.audioStreamIndex)
        assertFalse(request.capabilities.allowDirectPlay)
        assertEquals(listOf(3), ServerPlayback.burnInSubtitles(burnedIn.url).filter { it.selected }.map { it.index })

        val english = assertNotNull(ServerPlayback.switchAudio(burnedIn.url, 1))
        assertEquals(3, provider.playbackRequests.last().subtitleStreamIndex)

        val cleared = assertNotNull(ServerPlayback.switchSubtitle(english.url, null))
        assertNull(provider.playbackRequests.last().subtitleStreamIndex)
        assertTrue(ServerPlayback.burnInSubtitles(cleared.url).none { it.selected })
        ServerPlayback.stop(cleared.url)
    }

    @Test
    fun resumesFromTheServerOnlyWhenItWatchedMoreRecently() = runTest {
        val provider = FakeServerProvider().apply {
            userStates["7"] = listOf(ServerUserState("v7", positionMs = 30_000L, durationMs = 60_000L, played = false, lastPlayedEpochMs = 5_000L))
        }
        val connection = installFakeServer(provider)
        val url = assertNotNull(ServerPlayback.prepare(ServerStreams.candidates(ServerItemRef(connection.id, "7")).single()).playableDirectUrl)

        assertEquals(30_000L, ServerPlayback.newerResumePositionMs(url, savedAtEpochMs = null))
        assertEquals(30_000L, ServerPlayback.newerResumePositionMs(url, savedAtEpochMs = 4_000L))
        assertNull(ServerPlayback.newerResumePositionMs(url, savedAtEpochMs = 5_000L))
        assertNull(ServerPlayback.newerResumePositionMs("https://other.example/7", savedAtEpochMs = null))
        ServerPlayback.stop(url)
    }

    @Test
    fun directPlayLeavesTracksToThePlayer() = runTest {
        val connection = installFakeServer()
        val url = assertNotNull(ServerPlayback.prepare(ServerStreams.candidates(ServerItemRef(connection.id, "7")).single()).playableDirectUrl)

        assertTrue(ServerPlayback.audioTracks(url).isEmpty())
        assertTrue(ServerPlayback.burnInSubtitles(url).isEmpty())
        assertNull(ServerPlayback.switchAudio(url, 2))
        assertNull(ServerPlayback.switchSubtitle(url, 3))
        assertTrue(ServerPlayback.isServerSource(url))
        ServerPlayback.stop(url)
    }
}
